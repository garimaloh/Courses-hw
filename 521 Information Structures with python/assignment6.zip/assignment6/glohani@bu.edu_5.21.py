x = int(input("Enter the desired height. "))
l = [1]
for i in range(x):
    # Modified v
    print("Row", i + 1, l)
    newlist = []
    newlist.append(l[0])
    for i in range(len(l) - 1):
        newlist.append(l[i] + l[i+1])
    newlist.append(l[-1])
    l = newlist