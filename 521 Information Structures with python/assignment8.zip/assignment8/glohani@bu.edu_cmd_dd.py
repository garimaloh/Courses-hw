f = 0
p = 1
n = 1

def node(f):
    return [f, None, None]

string = """Beautiful is better than ugly.
Explicit is better than implicit.
Simple is better than complex.
Complex is better than complicated."""
nli = list(string)

length = string.split("\n")
k=0
cur = 53
s =0
xlist = []
for e in length:
    xlist.append(len(e))

while k<len(length):
    elem = node(length[k])
    if k==0:
        elem[p] = None
        elem[n] = None
        s = elem
    else:
        elem[p] = prev
        prev[n] = elem
        elem[n] = None
    prev = elem
    k = k+1

end = prev

l = len(prev[f])
next = s
i = 0
e = 0
eli = []
eli.append(0)
for e in range(0, len(nli)):
    if nli[e] == '\n':
        eli.append(e)
eli.append(len(nli))
total = 0

i = 0
print("\n")


def my_print(next, cursor):
    total = 0
    try:
        while next[f]!=None:
            target = next
            if cursor==0:
                print('^'+string)
                print("\n")
                break
            if (cursor > total and cursor < total+len(target[f])):
                current = cursor-total
                w = list(next[f])
                print(''.join(w[:current])+'^'+''.join(w[current:]))
            else:
                print(next[f])
            total = total+len(next[f])
            next = next[n]
    except:
        print(" ")


def cmd_dd(next, cursor):
    total = 0
    try:

        while next[f] != None:
        
            target = next
            flag = 0
            if cursor == 0:
                print('^' + string)
                print("\n")
                break

            if cursor > total and cursor < total + len(target[f]):
           
                current = cursor - total
                w = list(next[f])
             
                next = next[n]
                flag = flag + 1
                if flag == 1:
                    print('^' + next[f])
                    flag = 0

            else:
                if flag == 1:
                    print('^' + next[f])
                    flag = 0
                else:
                    print(next[f])
            total = total + len(next[f])
            next = next[n]


    except:
        print(" ")


my_print(next, cursor)


cmd_dd(next, cursor)




