# -*- coding: utf-8 -*-
"""
Created on Thu Feb 21 13:48:04 2019

@author: GARIMA
"""

print("Enter month and year")
month=float(input())
year=float(input())
if (month==1 or month==3 or month==5 or month==7 or month==8 or month==10 or month==12):
    print("number of days:31")
elif (month==2):
    if (year%4==0):
        print("number of days:29")
    else:
        print("number of days:28")
        