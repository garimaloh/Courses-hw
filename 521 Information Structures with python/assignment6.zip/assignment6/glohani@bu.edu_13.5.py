# -*- coding: utf-8 -*-
"""
Created on Sat Mar  2 13:05:11 2019

@author: GARIMA
"""

st =  input("Enter a String: ").split(" ")
#print (str)
list1 = []
list2 = []
for word in st:
    list1.append(word)

length = len(list1)
ostring = input("Enter the old string to be replaced: ")
nstring = input("Enter the new string to replace the old string: ")
f = 0
for i in list1:
    if i==ostring:
        f = 1
        list2.append(nstring)
    else:
        list2.append(i)

if f==1:
    print ("The entered string was found and replaced")
else:
    print ("The entered string was not found")
changes = ' '.join(list2)
print ("Done")
print (changes)