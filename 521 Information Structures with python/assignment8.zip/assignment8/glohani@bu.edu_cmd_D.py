f = 0
p = 1
n = 1

def node(f):
    return [f, None, None]

string = """Beautiful is better than ugly.
Explicit is better than implicit.
Simple is better than complex.
Complex is better than complicated."""
xlist = list(string)

length = string.split("\n")
k=0
cur = 53
start =0
dli = []
for e in length:
    dli.append(len(e))

while k<len(length):
    elem = node(length[k])
    if k==0:
        elem[p] = None
        elem[n] = None
        start = elem
    else:
        elem[p] = prev
        prev[n] = elem
        elem[n] = None
    prev = elem
    k = k+1

end = prev

l = len(prev[f])
next = start
i = 0
e = 0
eli = []
eli.append(0)
for e in range(0, len(xlist)):
    if xlist[e] == '\n':
        eli.append(e)
eli.append(len(xlist))
whole = 0

i = 0
print("\n")



def my_print(next, cursor):
    whole = 0
    try:
        while next[f]!=None:
            target = next
            if cursor==0:
                print('^'+string)
                print("\n")
                break
            if (cursor > whole and cursor < whole+len(target[f])):
                current = cursor-whole
                w = list(next[f])
                print(''.join(w[:current])+'^'+''.join(w[current:]))
            else:
                print(next[f])
            whole = whole+len(next[f])
            next = next[n]
    except:
        print(" ")


def cmd_D(next, cursor):
    whole = 0
    try:
 
        while next[f]!=None:
        
            target = next
            if cursor==0:
                print('^'+string)
                print("\n")
                break

            if cursor > whole and cursor < whole+len(target[f]):
                current = cursor-whole
                w = list(next[f])
                print(''.join(w[:current-1])+'^')
     


            else:
                print(next[f])
            
            whole = whole+len(next[f])
            next = next[n]

    except:
        print(" ")


my_print(next, cur)


cmd_D(next, cur+1)


