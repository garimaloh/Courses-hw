# -*- coding: utf-8 -*-
"""
Created on Thu Feb 21 13:56:42 2019

@author: GARIMA
"""

print ("number of student")

n=input()

print("enter the scores")
a = [int(x) for x in input().split()]
print(a)

h=a[0]
sh=a[1]

for i in a:
    
    if (i>h):
     sh=h
     h=i
        
print(h,sh)    