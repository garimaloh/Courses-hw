# -*- coding: utf-8 -*-
"""
Created on Thu Feb 28 09:58:29 2019

@author: GARIMA
"""

fee = 10000
fyf= 0
i= 1
while(i<=10):
    if(i<=4):
     fyf=fyf+fee
    count += 1
    print("year",i,"fees",round(fee,2))
    
    fee=fee+fee*0.05
    i=i+1
    
print("total four year fees ",fyf)    