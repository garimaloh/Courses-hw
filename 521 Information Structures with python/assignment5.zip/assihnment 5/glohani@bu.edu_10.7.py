# -*- coding: utf-8 -*-
"""
Created on Thu Feb 21 14:05:26 2019

@author: GARIMA
"""
from random import randint
a=[]
for i in range(10):
 n=random.randint(0,10)
 a.append(n)
 
print (a) 
for i in range(10):
 b= a.count(i)
 print("number of ",i,":",b)