# -*- coding: utf-8 -*-
"""
Created on Sat Mar  2 13:06:09 2019

@author: GARIMA
"""

filename = input("Enter a filename: ")
total, count = 0, 0

with open(filename, 'r') as f:
    for line in f:
        total += int(line.strip())
        count += 1

print("There are " + str(count) + " scores")
print("The total is " + str(total))
print("The average is " + str(total / count))