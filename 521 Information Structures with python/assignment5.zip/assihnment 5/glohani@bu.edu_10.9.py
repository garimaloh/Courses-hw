# -*- coding: utf-8 -*-
"""
Created on Thu Feb 21 17:32:01 2019

@author: GARIMA
"""

import math
def mean(x):
 return sum(x)/len(x)
def deviation(x):
 m = mean(x)
 v = 0
 for i in x:
  v += (i - m)**2
  v = v/(len(x) -1)
 return math.sqrt(v)

def main():
 data = input("Enter numbers: ")
 data = data.split()
 x = [float(i) for i in data]
 print("The mean is " + "{0:.2f}".format(mean(x)))
 print("The standard deviations is " + "{0:.5f}".format(deviation(x)))

if __name__ == '__main__':
 main()

# code l