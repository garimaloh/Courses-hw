f = 0
p = 1
n = 1

def node(f):
    return [f, None, None]

string = """Beautiful is better than ugly.
Explicit is better than implicit.
Simple is better than complex.
Complex is better than complicated."""
my_list = list(string)

length = string.split("\n")
k=0
cursor = 53
s =0
i_list = []
for e in length:
    i_list.append(len(e))

while k<len(l):
    elem = node(l[i])
    if k==0:
        elem[p] = None
        elem[n] = None
        start = elem
    else:
        elem[p] = prev
        prev[n] = elem
        elem[n] = None
    prev = elem
    k = k+1

end = prev
print('end',end[f])
ll = len(prev[f])
next = start
i = 0
e = 0
e_list = []
e_list.append(0)
for e in range(0, len(my_list)):
    if my_list[e] == '\n':
        e_list.append(e)
e_list.append(len(my_list))
whole = 0

i = 0
print("\n")

def my_print(next, cursor):
    whole = 0
    try:
        while next[f]!=None:
            target = next
            if cursor==0:
                print('^'+string)
                print("\n")
                break
            if (cursor > whole and cursor < whole+len(target[f])):
                current = cursor-whole
                w = list(next[f])
                print(''.join(w[:current])+'^'+''.join(w[current:]))
            else:
                print(next[f])
            whole = whole+len(next[f])
            next = next[n_n]
    except:
        print(" ")

def cmd_insert(next, cursor, user_str):
    whole = 0
    count = 0
    try:
    
        while next[f]!=None:
         
            target = next
            if cursor==0:
                print('^'+string)
                print("\n")
                break

            if cursor > whole and cursor < whole+len(target[f]):
        
                current = cursor-whole
                w = list(next[f])
                print(''.join(w[:current])+'^'+user_str+''.join(w[current:]))
          
            elif cursor > whole and cursor < whole+len(target[f]) and whole+len(target[f])==len(string):
                if count==3:
                    print(''.join(next[f])+'^')
                else:
                    print(next[f])



            else:
                print(next[f])

            whole = whole+len(next[f])
            next = next[n]
            count = count+1

    except:
        print(" ")




my_print(next, cursor)


user_str = input("Enter a string: ")
cmd_insert(next, cursor+1, user_str)




