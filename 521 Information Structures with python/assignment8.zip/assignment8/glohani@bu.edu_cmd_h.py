d = 0
p = 1
n = 1

def node(d):
    return [d, None, None]

string = """Beautiful is better than ugly.
Explicit is better than implicit.
Simple is better than complex.
Complex is better than complicated."""
xli = list(string)

lnew = string.split("\n")
k=0
cursor = 53
s =0
nli = []
for e in lnew:
    nli.append(len(e))

while k<len(lnew):
    elem = node(lnew[k])
    if k==0:
        elem[p] = None
        elem[n] = None
        start = elem
    else:
        elem[p] = prev
        prev[n] = elem
        elem[n] = None
    prev = elem
    k = k+1

end = prev
ll = len(prev[d])
next = start
i = 0
e = 0
eli = []
eli.append(0)
for e in range(0, len(xli)):
    if xli[e] == '\n':
        eli.append(e)
eli.append(len(xli))
total = 0

i = 0
print("\n")
def my_print(next, cursor):
    total = 0
    try:
        while next[d]!=None:
            target = next
            if cursor==0:
                print('^'+string)
                print("\n")
                break
            if (cursor > total and cursor < total+len(target[d])):
                temp = cursor-total
                w = list(next[d])
                print(''.join(w[:temp])+'^'+''.join(w[temp:]))
            else:
                print(next[d])
            total = total+len(next[d])
            next = next[n]
    except:
        print(" ")



def cmd_h(cursor):
    return cursor-1


print("Original String")
my_print(next, cursor)
print("cmd_h: ")
new_cursor = cmd_h(cursor)
my_print(next, new_cursor)



