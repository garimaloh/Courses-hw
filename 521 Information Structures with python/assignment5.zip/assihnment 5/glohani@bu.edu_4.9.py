# -*- coding: utf-8 -*-
"""
Created on Thu Feb 21 13:40:03 2019

@author: GARIMA
"""

print("Enter the weight and price of package 1")
w1=float(input())
p1=float(input())
print("Enter the weight and price of package 2")
w2=float(input())
p2=float(input())

if ((p1/w1) >(p2/w2)):
    print("package 1 has a better price")
elif ((p2/w2) <(p1/w1)) :   
    print("package 2 has a better price")