f = 0
p = 1
n = 1

def node(f):
    return [f, None, None]

string = """Beautiful is better than ugly.
Explicit is better than implicit.
Simple is better than complex.
Complex is better than complicated."""
xli = list(string)

length = string.split("\n")
k=0
cur = 53
s =0
nli = []
for e in length:
    nli.append(len(e))

while k<len(length):
    elem = node(length[k])
    if k==0:
        elem[p] = None
        elem[n] = None
        s = elem
    else:
        elem[p] = prev
        prev[n] = elem
        elem[n] = None
    prev = elem
    k = k+1

end = prev

l = len(prev[f])
next = s
i = 0
e = 0
eli = []
eli.append(0)
for e in range(0, len(xli)):
    if xli[e] == '\n':
        eli.append(e)
eli.append(len(xli))
whole = 0

i = 0
print("\n")


def my_print(next, cursor):
    whole = 0
    try:
        while next[f]!=None:
            target = next
            if cursor==0:
                print('^'+string)
                print("\n")
                break
            if (cursor > whole and cursor < whole+len(target[f])):
                current = cursor-whole
                w = list(next[f])
                print(''.join(w[:current])+'^'+''.join(w[current:]))
            else:
                print(next[f])
            whole = whole+len(next[f])
            next = next[n]
    except:
        print(" ")


def cmd_ddp(next, cursor):
    whole = 0
    try:

        while next[f] != None:
         
            target = next
            flag = 0

            if cursor >= whole and cursor <= whole + len(target[f]):
              
                prev = next
                next = next[n]
                current = cursor - whole
                w = list(next[f])
                print(''.join(w[:current]) + "^" + ''.join(w[current:]))
                s = list(prev[f])
                print(''.join(s[:current]) + ''.join(s[current:]))
                next = next[n]
                flag = flag + 1
                if flag == 1:
                    print(next[f])
                    flag = 0

            else:
                if flag == 1:
                    print(next[f])
                    flag = 0
                else:
                    print(next[f])
            whole = whole + len(next[f])
            next = next[n]


    except:
        print(" ")





my_print(next, cur)

cmd_ddp(next, cur)




