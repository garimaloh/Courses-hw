
# coding: utf-8

# In[1]:


def place_char(str_1,str_2,pos):
    return str_1[:pos]+str_2 + str_1[pos:]


# In[2]:


#Function 1

def cmd_h(inp_str):
    """This function moves cursor to one character to the left"""
    
    cur_pos=inp_str.index("^")
    
    if cur_pos==0:
        return inp_str
    res=inp_str[:cur_pos-1]+"^"+inp_str[cur_pos-1]+inp_str[cur_pos+1:]
    
    return res
    


# In[3]:


#Function 2

def cmd_l(inp_str):
    """This function moves cursor to one character to the right"""
    cur_pos=inp_str.index("^")
    
    if cur_pos==len(inp_str)-1:
        return inp_str
    
    res=inp_str[:cur_pos]+inp_str[cur_pos+1]+"^"+inp_str[cur_pos+2:]
    
    return res


# In[4]:


#Function 3

def cmd_j(inp_str):
    """This function moves cursor vertically one line down"""
    
    str_split=inp_str.split("\n")
    
    #print(str_split)
    cur_line_index=[0]*len(str_split)
    
    for i,str_1 in enumerate(str_split):
        if "^" in str_1:
            cur_line_index[i]=1
            break
    
    if cur_line_index.index(1)==len(str_split)-1:
        return inp_str
    
    cur_to_place_string=str_split[i+1]
    cur_pos=str_split[i].index("^")
    res_string=place_char(cur_to_place_string,"^",cur_pos)
    
    str_split[i+1]=res_string
    str_split[i]=str_split[i].replace("^","")
    
    res="\n".join(str_split)
    
    return res


# In[5]:


#Function 4

def cmd_k(inp_str):
    """This function moves cursor vertically one line up"""
    
    
    str_split=inp_str.split("\n")
    
    #print(str_split)
    cur_line_index=[0]*len(str_split)
    
    for i,str_1 in enumerate(str_split):
        if "^" in str_1:
            cur_line_index[i]=1
            break
    
    if cur_line_index.index(1)==0:
        return inp_str
    
    cur_to_place_string=str_split[i-1]
    cur_pos=str_split[i].index("^")
    res_string=place_char(cur_to_place_string,"^",cur_pos)
    
    str_split[i-1]=res_string
    str_split[i]=str_split[i].replace("^","")
    
    res="\n".join(str_split)
    
    return res


# In[6]:


#Function 5

def cmd_X(inp_str):
    """This function deletes one character to the left of cursor"""
    
    cur_pos=inp_str.index("^")
    
    if cur_pos==0:
        return inp_str
    
    res=inp_str[:cur_pos-1]+inp_str[cur_pos:]
    return res


# In[7]:


#Function 6

def cmd_D(inp_str):
    """This function removes on current line from cursor to the end"""
    
    
    str_split=inp_str.split("\n")
    
    #print(str_split)
    cur_line_index=[0]*len(str_split)
    
    for i,str_1 in enumerate(str_split):
        if "^" in str_1:
            cur_line_index[i]=1
            break
    
    cur_pos=str_split[i].index("^")
    res_string=str_split[i][:cur_pos+1]
    
    
    str_split[i]=res_string
    
    res="\n".join(str_split)
    
    return res


# In[8]:


#Function 7

def cmd_dd(inp_str):
    """This function deletes current line and move cursor to the beginning of next line"""
    
    
    str_split=inp_str.split("\n")
    
    #print(str_split)
    cur_line_index=[0]*len(str_split)
    
    for i,str_1 in enumerate(str_split):
        if "^" in str_1:
            cur_line_index[i]=1
            break

    
    del str_split[i]

    try:
        str_split[i]="^"+str_split[i]
    except:
        str_split[-1]=str_split[-1]+"^"
        
    res="\n".join(str_split)
    
    return res


# In[9]:


#Function 8

def cmd_ddp(inp_str):
    """This function transposes two adjacent lines"""
    
    
    str_split=inp_str.split("\n")
    
    #print(str_split)
    cur_line_index=[0]*len(str_split)
    
    for i,str_1 in enumerate(str_split):
        if "^" in str_1:
            cur_line_index[i]=1
            break

    try:
        a=str_split[i]
        b=str_split[i+1]
        str_split[i+1]=a
        str_split[i]=b
        str_split=cmd_k("\n".join(str_split)).split("\n")
    except:
        a=str_split[i]
        b=str_split[i-1]
        str_split[i-1]=a
        str_split[i]=b
        str_split=cmd_j("\n".join(str_split)).split("\n")
        
    res="\n".join(str_split)
    
    return res


# In[10]:


#Function 9

def cmd_n(inp_str,str_search):
    """This function search for next occurrence of a string 
    (assume that string to be searched is fully in one line 
    and place the cursor just before the next occurence"""
    
    inp_str=inp_str.replace("^","")
    
    str_split=inp_str.split("\n")
    
    #print(str_split)
    cur_line_index=[0]*len(str_split)
    
    for i,str_1 in enumerate(str_split):
        if str_search in str_1:
            cur_line_index[i]=1
            break
            
    str_index=str_split[i].index(str_search)
    try:
        next_str_index=str_split[i][str_index+1:].index(str_search)+str_index
        str_split[i]=place_char(str_split[i],"^",next_str_index+1)
        
    except:
        return inp_str
    
    return "\n".join(str_split)
    


# In[11]:


#Function 10

def cmd_wq(inp_str,filename):
    my_list=inp_str.split("\n")
    with open(filename, 'w') as f:
        for item in my_list:
            f.write("%s\n" % item)

