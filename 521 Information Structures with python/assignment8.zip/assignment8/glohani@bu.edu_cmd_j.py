d = 0
p = 1
n = 1

def node(d):
    return [d, None, None]

string = """Beautiful is better than ugly.
Explicit is better than implicit.
Simple is better than complex.
Complex is better than complicated."""
xlist = list(string)

length = string.split("\n")
k=0
cursor = 53
s =0
ili = []
for e in length:
    ili.append(len(e))

while k<len(length):
    elem = node(length[k])
    if k==0:
        elem[p] = None
        elem[n] = None
        s = elem
    else:
        elem[p] = prev
        prev[n] = elem
        elem[n] = None
    prev = elem
    k = k+1

end = prev

l = len(prev[d])
next = s
i = 0
e = 0
n_list = []
n_list.append(0)
for e in range(0, len(xlist)):
    if xlist[e] == '\n':
        n_list.append(e)
n_list.append(len(xlist))
total = 0

i = 0
print("\n")

def my_print(next, cursor):
    whole = 0
    try:
        while next[d]!=None:
            target = next
            if cursor==0:
                print('^'+string)
                print("\n")
                break
            if (cursor > whole and cursor < whole+len(target[d])):
                current = cursor-whole
                w = list(next[d])
                print(''.join(w[:current])+'^'+''.join(w[current:]))
            else:
                print(next[d])
            whole = whole+len(next[d])
            next = next[n_n]
    except:
        print(" ")

def cmd_j(next, cursor, n_list):
    i = 1

    if cursor <= n_list[1]:

        print("^"+string)
    else:
        try:
            while cursor > n_list[i]:
                i = i+1

            p_list = n_list[1:4]
            if cursor in p_list:
                x = n_list.index(cursor)
                x = x-2
              
                for i in range(0, x+1):
                    print(next[d])
                    next = next[n_n]
  
                print('^'+next[d])
                next = next[n_n]
                for i in range(x+2, 5+x):
                    print(next[d])
                    next = next[n_n]


            for r in range(1, i-1):
                print(next[d])
                next = next[n_n]
            current = cursor-n_list[i-1]
          
            w = list(next[d])
   
            print(''.join(w[:current]) + '^' + ''.join(w[current:]))

            next = next[n_n]
            for r in range(i+2, 4+i+1):
                print(next[d])
                next = next[n_n]

        except:
            print(" ")



print("Original String")
my_print(next, cursor)
print("cmd_j: ")
cmd_j(next, cursor, n_list)
print("\n")




