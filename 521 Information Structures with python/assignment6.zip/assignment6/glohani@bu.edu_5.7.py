# -*- coding: utf-8 -*-
"""
Created on Thu Feb 28 09:53:57 2019

@author: GARIMA
"""
from math import*
deg = 0
print("degrees                  sin             cos")
while deg <= 360:
    print(' {:d}                {:.4f}                 {:.4f}'.format(deg, sin(radians(deg)), cos(radians(deg))))
    deg += 10

