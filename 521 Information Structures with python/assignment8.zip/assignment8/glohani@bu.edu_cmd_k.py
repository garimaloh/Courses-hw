d = 0
n_p = 1
n_n = 1

def node(d):
    return [d, None, None]

string = """Beautiful is better than ugly.
Explicit is better than implicit.
Simple is better than complex.
Complex is better than complicated."""
nli = list(string)

length = string.split("\n")
k=0
cursor = 53
s =0
xli = []
for e in length:
    xli.append(len(e))

while k<len(length):
    elem = node(length[k])
    if k==0:
        elem[n_p] = None
        elem[n_n] = None
        start = elem
    else:
        elem[n_p] = prev
        prev[n_n] = elem
        elem[n_n] = None
    prev = elem
    k = k+1

end = prev

l = len(prev[d])
next = start
i = 0
e = 0
eli = []
eli.append(0)
for e in range(0, len(nli)):
    if nli[e] == '\n':
        eli.append(e)
eli.append(len(nli))
total = 0

i = 0
print("\n")

def my_print(next, cursor):
    total = 0
    try:
        while next[d]!=None:
            target = next
            if cursor==0:
                print('^'+string)
                print("\n")
                break
            if (cursor > total and cursor < total+len(target[d])):
                current = cursor-total
                w = list(next[d])
                print(''.join(w[:current])+'^'+''.join(w[current:]))
            else:
                print(next[d])
            total = total+len(next[d])
            next = next[n_n]
    except:
        print(" ")


def cmd_k(next, cursor, xlist):
    total = 0
    try:
        while next[d] != None:
            target = next
            e_list = xlist[0:3]
            if cursor in e_list:
                ind = e_list.index(cursor)
                for i in range(0, ind+1):
                    print(next[d])
                    next = next[n_n]

                print("^"+next[d])
                next = next[n_n]
                e = ind+2
                for i in range(ind+1, e):
                    print(next[d])

                break


            if cursor > total and cursor < total + len(target[d]):

                if cursor > 93:
                    print(''.join(next[d]) + '^')

                current = cursor - total
                line1 = len(next[d])
                n = next
                n = n[n_n]
                line2 = len(n[d])

                if line2 < current:
                    print(next[d])
                    print(next[n] + '^')

                else:
                    w = list(next[d])
                    print(next[d])

                    next = next[n_n]
                    w = list(next[d])
                    print(''.join(w[:current]) + '^' + ''.join(w[current:]))
            elif cursor >= total and cursor <= total + len(target[d]) and total + len(target[d]) == len(string):
                print("last line reached")

            else:
                print(next[d])
            total = total + len(next[d])
            next = next[n_n]

        if cursor >= ll:
            print("last line reached")

    except:
        print(" ")











my_print(next, cursor)

cmd_k(next, cursor, xlist)
